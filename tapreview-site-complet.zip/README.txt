TAPREVIEW — SITE VITRINE

Fichiers :
- index.html : contenu du site
- style.css : design et responsive
- script.js : menu mobile et formulaire
- README.txt : instructions

OUVRIR LE SITE
Double-cliquez sur index.html.

MISE EN LIGNE GRATUITE
Vous pouvez déposer ces trois fichiers sur :
- GitHub Pages
- Netlify
- Cloudflare Pages

FORMULAIRE
Le formulaire est actuellement en démonstration.
Vous pouvez le connecter à Formspree en remplaçant la balise :
<form class="contact-form" id="quoteForm">

par :
<form class="contact-form" action="VOTRE_LIEN_FORMSPREE" method="POST">

Puis supprimer dans script.js la partie qui bloque l'envoi du formulaire.
